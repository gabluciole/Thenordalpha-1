export default function NordAlphaHome() {
  const products = [
    {
      name: 'Manteau NordAlpha Noir',
      price: '$129',
      image:
        'https://images.unsplash.com/photo-1523398002811-999ca8dec234?q=80&w=1200&auto=format&fit=crop',
    },
    {
      name: 'Hoodie Boréal',
      price: '$79',
      image:
        'https://images.unsplash.com/photo-1503341504253-dff4815485f1?q=80&w=1200&auto=format&fit=crop',
    },
    {
      name: 'T-Shirt Alpha',
      price: '$39',
      image:
        'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?q=80&w=1200&auto=format&fit=crop',
    },
    {
      name: 'Casquette NordAlpha',
      price: '$34',
      image:
        'https://images.unsplash.com/photo-1521369909029-2afed882baee?q=80&w=1200&auto=format&fit=crop',
    },
  ];

  return (
    <div className="min-h-screen bg-black text-white">
      <section
        className="relative h-[90vh] flex items-center justify-center overflow-hidden"
        style={{
          backgroundImage:
            "linear-gradient(to bottom, rgba(0,0,0,.65), rgba(0,0,0,.92)), url('https://images.unsplash.com/photo-1448375240586-882707db888b?q=80&w=1600&auto=format&fit=crop')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="text-center px-6 max-w-4xl">
          <p className="uppercase tracking-[0.4em] text-sm text-green-400 mb-4">
            NordAlpha
          </p>

          <h1 className="text-5xl md:text-7xl font-black leading-tight mb-6">
            VÊTEMENTS
            <br />
            POUR LE NORD
          </h1>

          <p className="text-zinc-300 text-lg md:text-xl max-w-2xl mx-auto mb-8">
            Des vêtements conçus pour les hivers froids et un style nordique moderne.
          </p>

          <button className="bg-green-600 hover:bg-green-500 transition px-8 py-4 rounded-2xl font-semibold shadow-2xl">
            Voir la collection
          </button>
        </div>
      </section>
    </div>
  );
}
